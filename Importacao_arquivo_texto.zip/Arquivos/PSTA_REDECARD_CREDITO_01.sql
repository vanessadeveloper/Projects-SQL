CREATE OR REPLACE PROCEDURE PSTA_REDECARD_CREDITO(NOMEARQUIVO VARCHAR2) IS
   
   --Autor: VANESSA MENEZES
   --Data cria��o: 10/03/2017


  VARQUIVO  utl_file.file_type;
  vnSeqLote INTEGER;
  type t_letter is table of varchar2(500) INDEX BY BINARY_INTEGER;
  r_letter t_letter;
  l_string varchar2(500);
  c        number := 0;
  con      integer;

BEGIN
  execute immediate ('truncate table sta_auxredecard_mvrc');
  VARQUIVO := utl_file.fopen('/u02/oradata/orcl/importacao_cartao/',
                             NOMEARQUIVO,
                             'r');
  SELECT S_CARTAO_LOTE.NEXTVAL INTO vnSeqLote FROM DUAL;

  BEGIN
    loop
      utl_file.get_line(VARQUIVO, l_string);
      l_string := l_string;
      r_letter(c) := l_string;
      l_string := l_string;
      INSERT INTO sta_auxredecard_mvrc (linha) VALUES (r_letter(c));
      COMMIT;
    end loop;
  EXCEPTION
    WHEN No_data_found THEN
      utl_file.fclose(VARQUIVO);
  END;

 
  BEGIN

  
  insert into consinco.sta_cartaoloja
                 (select nomearquivo          as nomearquivo,
                       vnseqlote            as seqlote,
                       av.nrocartao         as nrocartao,
                       ec.nroempresamae     as nroempresamae,
                       ec.nroempresa        as nroempresa,
                       ec.cgcoperadora      as nrocgcoperadora,
                       ec.seqpessoa         as seqpessoa,
                       av.dtatransacao      as dtavenda,
                       av.dtatransacao      as dtadeposito,
                       fc5f_datautil(fsta_data_vencimento_cartao(av.dtatransacao,'1'),25962,'0','0','P',null) dtavencimento,
                       0                    as nroparcela,
                       0                    as totparcela,
                       av.vlr_cv_bruto      as vlrbruto,
                       av.vnpercentual      as vnpercentual,
                       ec.redeautorizada    as redeautorizada,
                       av.tipcartao         as tipcartao,
                       ec.administradora    as administradora,
                       sysdate              as dtainclusao,
                       'AUTOMATICO'         as usuinclusao,
                       'N'                  as indintegrado,
                       av.status            as status,
                       av.codautorizacao    as codautorizacao,
                       av.vlr_cv_liq        as vlrliquido,
                       av.nrocv             as nrocv
                       
   
                   from
                             (    
                        select substr(linha, 4, 9) as codstab,
                               substr(linha, 87, 12)   nrocv,
                               to_date(substr(linha, 22, 8), 'DD/MM/YYYY') as dtatransacao,
                               substr(linha, 68, 16) as nrocartao,
                               to_number(replace(to_char(substr(linha, 38, 15),'999999,99'),',','.'))    as vlr_cv_bruto,
                               to_number(replace(to_char(substr(linha, 204, 15),'999999,99'),',','.'))    as vlr_cv_liq,
                               to_number(replace(to_char(substr(linha, 112, 15),'FM999999999990D00'),',','.'))/100 as vlrdesconto,
                               round(((to_number(replace(to_char(substr(linha, 38, 15),'999999,99'),',','.')) - to_number(replace(to_char(substr(linha, 204, 15),'999999,99'),',','.')))/to_number(replace(to_char(substr(linha, 38, 15),'999999,99'),',','.')))*100,2) as vnpercentual,
                               substr(linha, 127, 6) as codautorizacao,
                               'Credito a vista'  as tipcartao,
                               decode(substr(linha, 203, 1), 2, 'P', 3, 'V','O') as status
                from consinco.sta_auxredecard_mvrc a
                         where linha like '008%') av, ---cr�dito � vista
                        sta_empcartao ec
                                where av.codstab = ec.codestab
                                and ec.administradora = 'REDECARD');
  commit;
   

 for rc in
               (select nomearquivo      as nomearquivo,
                       vnseqlote        as seqlote,
                       au.nrocartao     as nrocartao,
                       ec.nroempresamae as nroempresamae,
                       ec.nroempresa    as nroempresa,
                       ec.cgcoperadora  as nrocgcoperadora,
                       ec.seqpessoa     as seqpessoa,
                       au.dtatransacao  as dtavenda,
                       au.dtatransacao  as dtadeposito,
                       fc5f_datautil(fsta_data_vencimento_cartao(au.dtatransacao,'1'),25962,'0','0','P',null) dtavencimento,
                       1 as nroparcela,
                       au.tot_parcelas  as totparcela,
                       round((au.vlr_cv_bruto/au.tot_parcelas),2) as vlr_bruto_primeira_parcela,
                       au.vlr_cv_bruto  as vlrbruto,
                       au.vnpercentual  as vnpercentual,
                       ec.redeautorizada as redeautorizada,
                       au.tipcartao     as tipcartao,
                       ec.administradora as administradora,
                       sysdate          as dtainclusao,
                       'AUTOMATICO'     as usuinclusao,
                       'N'              as indintegrado,
                       au.status        as status,
                       au.codautorizacao as codautorizacao,
                       au.vlrliqpriparcela  as vlr_liquido_parcela,
                       au.vlrliqsegparcela  as vlr_demais_parcelas,
                       au.vlrliquido        as vlrliquido,
                       au.nrocv          as nrocv
                       
   
                   from
                             (select
                               substr(linha, 4, 9) as codstab,
                               substr(linha, 89, 12)   nrocv,
                               to_date(substr(linha, 22, 8), 'DD/MM/YYYY') as dtatransacao,
                               substr(linha, 87, 2) as tot_parcelas,
                               substr(linha, 68, 16) as nrocartao,
                               to_number(replace(to_char(substr(linha, 221, 15),'999999,99'),',','.'))    as vlrliqpriparcela,
                               to_number(replace(to_char(substr(linha, 236, 15),'999999,99'),',','.'))    as vlrliqsegparcela,
                               to_number(replace(to_char(substr(linha, 206, 15),'999999,99'),',','.')) as vlrliquido,
                               to_number(replace(to_char(substr(linha, 114, 15),'FM999999999990D00'),',','.'))/100 as vlrdesconto,
                               to_number(replace(to_char(substr(linha, 38, 15),'999999,99'),',','.')) as vlr_cv_bruto,
                               to_number(replace(to_char(substr(linha, 206, 15),'999999,99'),',','.')) + to_number(replace(to_char(substr(linha, 114, 15),'FM999999999990D00'),',','.'))/100 as vlr_bruto,
                               round(((to_number(replace(to_char(substr(linha, 38, 15),'999999,99'),',','.')) - to_number(replace(to_char(substr(linha, 206, 15),'999999,99'),',','.')))/to_number(replace(to_char(substr(linha, 38, 15),'999999,99'),',','.')))*100,2) as vnpercentual,
                               substr(linha, 129, 6) as codautorizacao,
                               'Credito a parcelado'  as tipcartao,
                               decode(substr(linha, 205, 1), 2, 'P', 3, 'V','O') as status
                from consinco.sta_auxredecard_mvrc a
                         where linha like '012%') au, ---cr�dito parcelado
                        sta_empcartao ec
                                where au.codstab = ec.codestab
                                and ec.administradora = 'REDECARD') loop
                                
    insert into consinco.STA_CARTAOLOJA values (
          rc.nomearquivo,
          rc.seqlote,
          rc.nrocartao,
          rc.nroempresamae,
          rc.nroempresa,
          rc.nrocgcoperadora,
          rc.seqpessoa,
          rc.dtavenda,
          rc.dtadeposito,
          rc.dtavencimento,
          rc.nroparcela,
          rc.totparcela,
          rc.vlr_bruto_primeira_parcela,
          rc.vnpercentual,
          rc.redeautorizada,
          rc.tipcartao,
          rc.administradora,
          rc.dtainclusao,
          rc.usuinclusao,
          rc.indintegrado,
          rc.status,
          rc.codautorizacao,
          rc.vlr_liquido_parcela,
          rc.nrocv);
          
              COMMIT;
    
     psta_parcelas_redecard012(rc.nomearquivo,rc.seqlote,rc.nrocartao,rc.nroempresamae,rc.nroempresa,rc.nrocgcoperadora,rc.seqpessoa,
                              rc.dtavenda,rc.dtadeposito,rc.totparcela,rc.vnpercentual,rc.redeautorizada,rc.tipcartao,rc.administradora,
                              rc.status,rc.codautorizacao,rc.nrocv,rc.vlr_demais_parcelas,
                              rc.vlrbruto);       
          
          end loop;
                                 
      
   
  END;



end PSTA_REDECARD_CREDITO;
